import React, { useState } from 'react';
import './App.css';
import Footer from './Footer';
import Page1 from './Page1';
import SkillsSection from './SkillSection';
import NavBar from './navBar';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  return (
    <div className="App">
      <NavBar setCurrentPage={setCurrentPage} />
      {currentPage === 'skills' ? <SkillsSection /> : <Page1 />}
      <Footer />
    </div>
  );
  
}

export default App;

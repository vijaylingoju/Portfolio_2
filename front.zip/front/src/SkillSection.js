import React, { useState, useEffect } from 'react';
import SkillCard from './SkillCard'; // Adjust the import path as needed
import SkillPopup from './SkillPopup'; // Adjust the import path as needed
import Skills from './Skills'; // Assuming this is a section or component for skill display

export default function SkillsSection() {
  const [showPopup, setShowPopup] = useState(false);
  const [skills, setSkills] = useState([]);

  // Fetch skills data when the component mounts
  useEffect(() => {
    const fetchSkills = async () => {
      try {
        const response = await fetch('http://localhost:5000/skillsData');
        const data = await response.json();
        setSkills(data || []);
      } catch (error) {
        console.error('Failed to fetch skills data', error);
      }
    };

    fetchSkills();
  }, []);

  const handleAddSkill = () => {
    setShowPopup(true);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  // Handle the submission of new skills and update local state
  const handleSubmit = async (newSkills, categoryTitle) => {
    const data = {
      domain: categoryTitle,
      skills: newSkills.map(skill => ({
        name: skill.skill,
        proficiency: `${skill.proficiency}%`,
      })),
    };

    try {
      const response = await fetch('http://localhost:5000/skillsData', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        console.log('Skills added successfully');
        // Directly update local state with new skills
        setSkills((prevSkills) => {
          const updatedSkills = [...prevSkills];
          const existingCategoryIndex = updatedSkills.findIndex(skillGroup => skillGroup.domain === categoryTitle);

          if (existingCategoryIndex > -1) {
            // If category exists, update skills
            updatedSkills[existingCategoryIndex].skills = [
              ...updatedSkills[existingCategoryIndex].skills,
              ...newSkills.map(skill => ({
                name: skill.skill,
                proficiency: `${skill.proficiency}%`,
              })),
            ];
          } else {
            // If category does not exist, add a new one
            updatedSkills.push({
              domain: categoryTitle,
              skills: newSkills.map(skill => ({
                name: skill.skill,
                proficiency: `${skill.proficiency}%`,
              })),
            });
          }

          return updatedSkills;
        });

        setShowPopup(false); // Close the popup after successful submission
      } else {
        console.error('Failed to add skills');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="container mx-auto p-4 bg-customBackground">
      <Skills />
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {skills.map((skillGroup) => (
          <SkillCard key={skillGroup.id} title={skillGroup.domain} skills={skillGroup.skills} />
        ))}
      </div>
      {showPopup && (
        <SkillPopup onClose={handleClosePopup} onSubmit={handleSubmit} />
      )}
      <div className="flex justify-center mb-4">
        <button
          onClick={handleAddSkill}
          className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded"
        >
          ADD SKILL
        </button>
      </div>
    </div>
  );
}

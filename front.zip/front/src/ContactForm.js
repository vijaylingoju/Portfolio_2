import React, { useState } from "react";

function ContactForm() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.fullName) {
      newErrors.fullName = "Full Name is required.";
    }

    if (!formData.email) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email address is invalid.";
    }

    if (!formData.message) {
      newErrors.message = "Message is required.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      const response = await fetch("http://localhost:5000/contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert("Message sent successfully!");
        setFormData({
          fullName: "",
          email: "",
          subject: "",
          message: "",
        });
      } else {
        alert("Failed to send message.");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("An error occurred while sending your message.");
    }
  };

  return (
    <div className="flex flex-col md:flex-row gap-4 container mt-[100px] px-4 mx-auto">
      <div className="w-full md:w-3/4 flex items-center justify-center flex-col">
        <div className="w-[95%]">
          <div className="flex w-full mb-5">
            <h2 className="text-2xl font-bold">Leave ME Your Info</h2>
          </div>
          <div className="w-[95%] bg-white">
            <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
              <div>
                <label
                  htmlFor="fullName"
                  className="text-gray-700 text-sm font-bold mb-2 flex ml-5 mt-5"
                >
                  Your Full Name (Required)
                </label>
                <input
                  type="text"
                  id="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  className="shadow bg-gray-200 appearance-none border rounded w-[95%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                {errors.fullName && (
                  <p className="text-red-500 text-xs italic ml-5">
                    {errors.fullName}
                  </p>
                )}
              </div>
              <div>
                <label
                  htmlFor="email"
                  className="flex ml-5 text-gray-700 text-sm font-bold mb-2"
                >
                  Your Email (Required)
                </label>
                <input
                  type="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="shadow appearance-none bg-gray-200 w-[95%] border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
                {errors.email && (
                  <p className="text-red-500 text-xs italic ml-5">
                    {errors.email}
                  </p>
                )}
              </div>
              <div>
                <label
                  htmlFor="subject"
                  className="flex ml-5 text-gray-700 text-sm font-bold mb-2"
                >
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="shadow appearance-none bg-gray-200 border rounded w-[95%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
              </div>
              <div>
                <label
                  htmlFor="message"
                  className="text-gray-700 text-sm font-bold mb-2 flex ml-5"
                >
                  Your Message
                </label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={handleChange}
                  className="shadow appearance-none bg-gray-200 border rounded w-[95%] py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  rows="5"
                />
                {errors.message && (
                  <p className="text-red-500 text-xs italic ml-5">
                    {errors.message}
                  </p>
                )}
              </div>
              <button
                type="submit"
                className="bg-yellow-500 ml-5 mb-5 hover:bg-yellow-600 text-black font-semibold rounded-[4px] text-[16px] w-[120px] lg:w-[150px] h-[50px]"
              >
                SEND MESSAGE
              </button>
            </form>
          </div>
        </div>
      </div>
      <div className="w-full md:w-1/4 flex flex-col gap-1 md:pr-8">
        <h2 className="text-2xl font-bold mb-4">Contact Information</h2>
        <div className="flex flex-col gap-4">
          <div className="bg-gray-100 p-4 rounded-lg shadow relative">
          <div className="w-10 h-10 flex items-center justify-center rounded-full bg-yellow-400 mx-auto mb-4">
              <svg
                width="19"
                height="19"
                viewBox="0 0 19 19"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_1150_1982)">
                  <path
                    d="M1.79102 4.43659L7.07928 2.17468L11.6121 4.43659L16.3738 2.40012C16.4313 2.37553 16.494 2.36556 16.5562 2.37112C16.6185 2.37668 16.6785 2.39759 16.7307 2.43197C16.7829 2.46635 16.8257 2.51313 16.8553 2.5681C16.8849 2.62308 16.9004 2.68453 16.9003 2.74694V14.9921L11.6121 17.254L7.07928 14.9921L2.31758 17.0286C2.26009 17.0532 2.1974 17.0632 2.1351 17.0576C2.07281 17.052 2.01288 17.0311 1.96068 16.9968C1.90849 16.9624 1.86566 16.9156 1.83605 16.8606C1.80643 16.8057 1.79096 16.7442 1.79102 16.6818V4.43659ZM11.6121 15.5682V6.07722L11.563 6.09833L7.07928 3.86056V13.3515L7.12838 13.3304L11.6121 15.5682Z"
                    fill="#2B2B2B"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_1150_1982">
                    <rect
                      width="18.1312"
                      height="18.0952"
                      fill="white"
                      transform="translate(0.28009 0.666748)"
                    />
                  </clipPath>
                </defs>
              </svg>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">Country:</span>
                <span className="text-gray-700">Bangladesh</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">City:</span>
                <span className="text-gray-700">Dhaka</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700 font-bold">Street:</span>
                <span className="text-gray-700">35 Vhatara, Badda</span>
              </div>
            </div>
          </div>
          <div className="bg-gray-100 p-4 rounded-lg shadow relative">
          <div className="w-10 h-10 flex items-center justify-center rounded-full bg-yellow-400 mx-auto mb-4">
              <svg
                width="19"
                height="19"
                viewBox="0 0 19 19"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_7632_568)">
                  <path
                    d="M2.54648 3.13495H16.1449C16.3452 3.13495 16.5374 3.21438 16.6791 3.35578C16.8207 3.49718 16.9003 3.68895 16.9003 3.88892V15.9524C16.9003 16.1524 16.8207 16.3441 16.6791 16.4855C16.5374 16.6269 16.3452 16.7064 16.1449 16.7064H2.54648C2.34612 16.7064 2.15396 16.6269 2.01229 16.4855C1.87061 16.3441 1.79102 16.1524 1.79102 15.9524V3.88892C1.79102 3.68895 1.87061 3.49718 2.01229 3.35578C2.15396 3.21438 2.34612 3.13495 2.54648 3.13495ZM9.391 9.68165L4.54696 5.5763L3.56863 6.72535L9.40083 11.6676L15.128 6.72158L14.1399 5.58082L9.39176 9.68165H9.391Z"
                    fill="#2B2B2B"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_7632_568">
                    <rect
                      width="18.1312"
                      height="18.0952"
                      fill="white"
                      transform="translate(0.28009 0.873047)"
                    />
                  </clipPath>
                </defs>
              </svg>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">Email:</span>
                <span className="text-gray-700">Youremail@Gmail.Com</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">Skype:</span>
                <span className="text-gray-700">@Yourusername</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700 font-bold">Telegram:</span>
                <span className="text-gray-700">@Yourusername</span>
              </div>
            </div>
          </div>
          <div className="bg-gray-100 p-4 rounded-lg shadow relative">
          <div className="w-10 h-10 flex items-center justify-center rounded-full bg-yellow-400 mx-auto mb-4">
              <svg
                width="19"
                height="19"
                viewBox="0 0 19 19"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_7632_564)">
                  <path
                    d="M4.8129 1.58752H13.8785C14.0789 1.58752 14.271 1.66696 14.4127 1.80836C14.5544 1.94975 14.634 2.14153 14.634 2.34149V15.9129C14.634 16.1129 14.5544 16.3047 14.4127 16.4461C14.271 16.5875 14.0789 16.6669 13.8785 16.6669H4.8129C4.61254 16.6669 4.42038 16.5875 4.27871 16.4461C4.13703 16.3047 4.05743 16.1129 4.05743 15.9129V2.34149C4.05743 2.14153 4.13703 1.94975 4.27871 1.80836C4.42038 1.66696 4.61254 1.58752 4.8129 1.58752ZM9.3457 12.897C9.14533 12.897 8.95318 12.9765 8.8115 13.1179C8.66982 13.2593 8.59023 13.4511 8.59023 13.651C8.59023 13.851 8.66982 14.0428 8.8115 14.1842C8.95318 14.3255 9.14533 14.405 9.3457 14.405C9.54606 14.405 9.73821 14.3255 9.87989 14.1842C10.0216 14.0428 10.1012 13.851 10.1012 13.651C10.1012 13.4511 10.0216 13.2593 9.87989 13.1179C9.73821 12.9765 9.54606 12.897 9.3457 12.897Z"
                    fill="#2B2B2B"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_7632_564">
                    <rect
                      width="18.1312"
                      height="18.0952"
                      fill="white"
                      transform="translate(0.28009 0.0795898)"
                    />
                  </clipPath>
                </defs>
              </svg>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">
                  Support Services:
                </span>
                <span className="text-gray-700">15369</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-bold">Office:</span>
                <span className="text-gray-700">+58 (021)356 587 235</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700 font-bold">Personal:</span>
                <span className="text-gray-700">+58 (021)356 587 235</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ContactForm;

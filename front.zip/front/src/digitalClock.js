import React from 'react'
import { useEffect } from 'react';
const DigitalClock = () => {
    const [hours, setHours] = React.useState("");
    const [minutes, setMinutes] = React.useState("");
    const [seconds, setSeconds] = React.useState("");
    let [ampm,SetAmPm] = React.useState("")
    useEffect(()=>{ 
       const updateTime = () => {
        const now = new Date();
        let hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();
        // console.log(typeof(hours))
        const ampm= hours>=12? "PM":"AM"
        if(hours>12){
            hours-=12
        }else if(hours===0){
            hours=12
        }
        
        setHours(hours.toString().padStart(2, '0'));
        setMinutes(minutes.toString().padStart(2, '0'));
        setSeconds(seconds.toString().padStart(2, '0'));
        SetAmPm(ampm)
       }
       const intervalId = setInterval(updateTime, 1000);
       return () => clearInterval(intervalId);
        
    },[])

  return (
    <div>
        <h1 className='text-5xl text-red-500'>Current Time</h1>
        <h1 className='text-9xl'>
            <span id="hours">{hours}</span>
            <span id="colon1">:</span>
            <span id="minutes">{minutes}</span>
            <span id="colon2">:</span>
            <span id="seconds">{seconds} </span>
            <span id="ampm">{ampm}</span>     
        </h1>
    </div>
  )
}

export default DigitalClock;


import React from 'react';

const Footer = () => {
  return (
    <div className="container mx-auto px-4 py-8" id="footer">
      <div className="grid grid-cols-4 ">
        <div className="flex flex-col items-center justify-center">
          <img src="https://s3-alpha-sig.figma.com/img/d8a6/a35a/27bc8f436587f1e07368ad18e8b41574?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=OwBVVQeLALFducZX9IbLT1QPlUX253F-0D1aqdXmiH2pJ3iW5bdz~r2qipJYlObs~Y-heVgaj2OQtR7907Maa8sWwXSHe9W0exmbgjAdk9Z5n88PZronq-d3RmhAtONXGc6fPA59x2EQBpicoriPNBeash3eYwZMg19ZBHUKv-THMB55ibiflf-MSEtu9NYV~FbuJi4KffvXj~3IDXF8oJV80T9zJvWUsp0RjLJcp9s9PyEyDscXPkGi65MIbIrrpHxfsJWnvCGZYyZAYGH3aPK4EdmaEw8GNzxkZ9m6AJKJxWMgryF5wCNaV19M-ssuprrsXdSAJCAhnRPkd42sMQ__" 
          alt="Image 1" className="w-24 h-24 rounded-full" />
        </div>
        <div className="flex flex-col items-center justify-center">
          <img src="https://s3-alpha-sig.figma.com/img/5642/838d/c24252f390d173e1a61464b19a0717c3?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=hWb~EGjcuUlmH29p6sHi3FTiqgZ6ixiBRmszIQdTV0dNBEpsPDWHBEXssV2y3BpqaPSVCEZqxxUqO3a~9LeZ6IXK-o10UuhqxLxehbIerg63TT05e8vhurDUHthdOcIqUNg8Xsz7K5ObnX08vrts8edTkKA1tV6jixJxcJFZ6H7FTOm6~m88EX7-nuxMnEOJboKVpJ6A71iYw1TE2XNNdephE4glgr44KTB1CeOcATUFJ5BAOuXdmO51HrgB0MMIYqRB4tQErR9U5Y~-iONSkWiEdOnDWEjwNOykLjK8vyLB2NmSV0A4e-Ds~TWWwxmMTgYhmf4AMUtdsyGgXZPqAg__" 
          alt="Image 2" className="w-24 h-24 rounded-full" />
        </div>
        <div className="flex flex-col items-center justify-center">
          <img src="https://s3-alpha-sig.figma.com/img/a5a9/02f4/8b606615b3d458f4817845911df9c5f4?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Uo6IlwDZDm0cpOaK5XGab6EO3u6y9Eom4xUMp~sjXgow~JZs9g2jykDte9Bs2Hg20zDzdZP9s0Y6i6rfzB-WRFQzkZ06rfoTDl7jNzIChDe3f4rS6g7lSeQKAZoyprOB4XFjkHAMfS-8qSUzDAV0RNTUFpYsi6MOg~rNFe~jHN7aCG6qEVi0Ng2G-r15culfKL87ntyzdI6Xl0ZZ6MF1UFqrRMynU5zdsQDMWv9BxVbseIjKlL090H2yVCOAAdC9Xe2c-OFBZdarDP-JABdsN4UfZFKeJ1LwdAE0~02TXWTwsk-0WQl8MRgL-l6ny56H0kC28xEFRNu0O2MG7FwrtQ__" 
          alt="Image 3" className="w-24 h-24 rounded-full" />
        </div>
        <div className="flex flex-col items-center justify-center">
          <img src="https://s3-alpha-sig.figma.com/img/5b3c/4250/41a5414d6d1bc655a8907011e864b498?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=KZkp61PfnxNuikJ1bp1O5Mr5gRYMcS-o5jHJBpJki-EgbvqyeDIlPVCVjKtiIvR8jsdmqrsvB8vilFd18uPmCNr6KRyBPwlsVD76No-WH1l6Lg6sbL1Im6CPDU2oqihfCBYOXfJu9o0uRGLYoYFLBouJc94XUVoTnDjP0hSrYGRoR44Uco9RZ0wIcjNBQxYzXYUA2iswtpBz2n~zKmHGWnQ9k66X2tp-3oxvfUKwR2FB-q3D0qau3vWHl-Jy-s0oBIasHgxg9eEwskUq-uihfKNE7CBeLhnzItvC0qvcWzqBfaqrldEryH9l9CY55~CX~uAw9Id0mTo7~wGA~H9xpQ__" 
          alt="Image 4" className="w-24 h-24 rounded-full" />
        </div>
      </div>
      <div className="grid grid-cols-4 gap-8 mt-8">
      <div className="flex flex-col items-start">
            <img src="./logo.png" alt="logo" />
            <div className="h-[100px]">
        <div className="flex flex-col items-center mt-20">
          <img src="https://s3-alpha-sig.figma.com/img/1a17/093d/35f03fdc5679fef2b564c376c8abd5f3?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=RLRKQxOoyC9gSzwOuUTo38JCHz3Nu27n09ajqQmu2VtLGJET4G6JaFuk-kc7kDCGOGvItQ6DznnAemeDLVF77~mKwKO9lzLDtcN5qV2fY3pDmLGTyRS3VMRpqMgA1VehTJP~k2Ev32M03loOxszMK8d4flKzdGBwddmMLrdr9SCW7hq6HGqtd~dSQVoHp3dWwiXsfqfaRgwLBIVWy2Ona6JQe45pLPrBqBnTMF3dWW7mT~7-7mgXLj3S3R6ptt-82atGyxbz5MQXQHnN3IRaZOd9k2J3ZgglJo~hhFjBGnez4ZRLSeOCOHgaTOa-dRJu5bmWuP49Krq-WQ8Ra3aWgg__" 
          alt="Image 1" className="w-24 h-15 " />
          <p className="text-center">4.5/5 Rating On Lorem</p>
        </div>
        <div className="flex flex-col items-center justify-center mt-5">
          <img src="https://s3-alpha-sig.figma.com/img/ba01/f2ce/09258b3d57d703dc1090dcc3890273ce?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=XyDHGPYAzyfUfwB20c4seGs~CWROvXQ8mBCqBRiHRV2TvqdsWxG1YEUEluSzoF-FWpnNls6jAREy33s2ElyL2I~KalK2GB5sKBIvmojz65x5gPRSxHOZ95NS59OV~nZJrkk8AqqnwH-qOIYidDavquf8HIs8vvDHrzUY0pM8ooA344NCCCdORhxq-0ESwB5M3IjumE9DshWrubLOOVxKarHYrTVpYciPxjqTnzsUTubs3F8ogj5c51Deu2jY~8HQjwtGKrBWLeDdZ2MEh7g-B9XKB106Huw89n5cPhHrruo3ao7ZH1lG27YT3lLVz3hyZk7X611JQbAPl5IY~OZnBQ__" 
          alt="Image 2" className="w-24 h-15 " />
          <p className="text-center">4.5/5 Rating On Lorem</p>
        </div>
        <div className="flex flex-col items-center justify-center mt-5">
          <img src="https://s3-alpha-sig.figma.com/img/af87/d658/2c3781ebf0ffeee18b63ea4855c4db1a?Expires=1724630400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Fb50iEoW1pnbTSIxGJyLEu3ruF3QiNn9cHQrRW3La27o~eah93qRmsLrwniWOCD5kpq9GQJtLah8WiiH6~wDCuCZbcIyz~5A0OSzN5fVKqxSpG~T3UNjvrpwVsPBcZ6v~ao6Rd4ytfcxlHeLPd9nHLBwbNF1-hWh5fExBbs9JuRNV-LKHBbf1ueVAgb~z8NTczFwhS2SDniWeYvYoU2FE7z-QWvKAC5jJ~jjlBNMf-1ObEo-URuu~11k5AW3nF7uGJYaMD1Kib1uvJAnjNuFmkXBlablixnWosA5MKy6iFo47Ne5eJNG6B32lBDBeDzS7zidjMCNdwjTN1r7GGRXZw__" 
          alt="Image 4" className="w-24 h-15 " />
          <p className="text-center">4.5/5 Rating On Lorem</p>
        </div>
      </div>
        </div>
        <div className="flex flex-col items-start mt-[200px]">
          <h2 className="text-2xl font-bold mb-4">Quick Links</h2>
          <ul>
            <li>Home</li>
            <li>Skills</li>
            <li>Education</li>
            <li>Projects</li>
            <li>Recommendations</li>
          </ul>
        </div>
        <div className="flex flex-col items-start mt-[200px]">
          <h2 className="text-2xl font-bold mb-4">Portfolio</h2>
          <ul>
            <li>Frontend Development</li>
            <li>Backend Development</li>
            <li>Website Design</li>
            <li>Machine Learning</li>
            <li>Problem Solving & DSA</li>
          </ul>
        </div>
        <div className="flex flex-col items-start mt-[200px]">
          <h2 className="text-2xl font-bold mb-4">Connect</h2>
          <ul>
            <li><a href="#" className="underline">LinkedIn</a></li>
            <li><a href="#" className="underline">Instagram</a></li>
            <li><a href="#" className="underline">Facebook</a></li>
          </ul>
        </div>
        
      </div>
      <div className="text-center mt-8">
        <p>&copy; 2024 Copyright, All Rights Reserved</p>
      </div>
    </div>
  );
}

export default Footer;

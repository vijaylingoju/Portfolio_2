import React, { useState } from 'react';

const SkillPopup = ({ onClose }) => {
  const [skills, setSkills] = useState([
    { skill: '', proficiency: 0 },
    { skill: '', proficiency: 0 },
    { skill: '', proficiency: 0 },
    { skill: '', proficiency: 0 },
    { skill: '', proficiency: 0 },
  ]);
  const [categoryTitle, setCategoryTitle] = useState('Front End Development');

  const handleSkillChange = (index, e) => {
    const updatedSkills = [...skills];
    updatedSkills[index].skill = e.target.value;
    setSkills(updatedSkills);
  };

  const handleProficiencyChange = (index, e) => {
    const updatedSkills = [...skills];
    updatedSkills[index].proficiency = e.target.value;
    setSkills(updatedSkills);
  };

  const handleCategoryChange = (e) => {
    setCategoryTitle(e.target.value);
  };

  const addSkills = async () => {
    const validSkills = skills.filter(({ skill, proficiency }) => skill && proficiency > 0);
    if (validSkills.length) {
      const data = {
        domain: categoryTitle,
        skills: validSkills.map(({ skill, proficiency }) => ({
          name: skill,
          proficiency: `${proficiency}%`,
        })),
      };

      // Post the data to the API endpoint
      try {
        const response = await fetch('http://localhost:5000/skillsData', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          console.log('Skills added successfully');
          // Reset the form
          window.location.reload()
          setSkills([
            { skill: '', proficiency: 0 },
            { skill: '', proficiency: 0 },
            { skill: '', proficiency: 0 },
            { skill: '', proficiency: 0 },
            { skill: '', proficiency: 0 },
          ]);
          setCategoryTitle('Front End Development');
          onClose(); // Close the popup after successful submission
          
        } else {
          console.error('Failed to add skills');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-50 z-50">
      <div className="bg-white p-6 max-w-lg w-full rounded-lg shadow-md">
        <h2 className="text-xl font-bold mb-4">Add Skills</h2>

        <div className="mb-4">
          <div className='flex justify-between mb-5 font-bold'>
            <div><h1>Domain</h1></div>
            <div><h3></h3></div>
          </div>
          <input
            type="text"
            id="category"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            value={categoryTitle}
            onChange={handleCategoryChange}
          />
        </div>
        <div className='flex justify-between mb-5 font-bold'>
          <div><h1>Skills</h1></div>
          <div><h3></h3></div>
        </div>
        <div className='flex justify-between'>
          <div><h3>Skill</h3></div>
          <div><h3>Proficiency (%)</h3></div>
        </div>
        {skills.map((skill, index) => (
          <div key={index} className="mb-4">
            <div className="flex items-center">
              <input
                type="text"
                id={`skill-${index}`}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                placeholder="Skill"
                value={skill.skill}
                onChange={(e) => handleSkillChange(index, e)}
              />
              <input
                type="number"
                className="shadow appearance-none border rounded w-24 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ml-2"
                placeholder="Proficiency (%)"
                value={skill.proficiency}
                onChange={(e) => handleProficiencyChange(index, e)}
              />
            </div>
          </div>
        ))}

        <div className="flex justify-end">
          <button
            className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded mr-2"
            onClick={addSkills}
          >
            Add Skills
          </button>
          <button
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default SkillPopup;

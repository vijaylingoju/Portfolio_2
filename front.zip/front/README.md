# Front End Project

## Overview

This project is a front-end application built with React, styled using Tailwind CSS, and uses `json-server` for mock API data. It includes various components such as a navigation bar, reviews list, and contact form.

## Features

- React-based UI
- Tailwind CSS for styling
- Mock API using `json-server`
- Concurrently runs both the server and React development environment

## Getting Started

### Prerequisites

- Node.js and npm installed on your machine

### Installation

1. **Clone the repository:**

    ```bash
    git clone <repository-url>
    cd front
    ```

2. **Install the dependencies:**

    ```bash
    npm install
    ```

### Running the Project

1. **Start the development server and JSON server concurrently:**

    ```bash
    npm start
    ```

   This command will:
   - Start the JSON server on port 5000 (as specified in `server` script).
   - Start the React development server on the default port 3000.

2. **Build the project:**

    ```bash
    npm run build
    ```

3. **Run tests:**

    ```bash
    npm test
    ```

4. **Eject configuration (if needed):**

    ```bash
    npm run eject
    ```

### Tailwind CSS

To build the Tailwind CSS styles, use the following command:

```bash
npm run build tailwind


##API Documentation
## Endpoints

### ProjectCards

- **Endpoint**: `/cards`
- **Method**: `GET`
- **Description**: Retrieves a list of project cards.

#### Response Schema

```json
{
  "cards": [
    {
      "title": "string",
      "description": "string",
      "technologies": [
        "string"
      ],
      "image": "string"
    }
  ]
}

### RecommendationCards

- **Endpoint**: `/reviews`
- **Method**: `GET`
- **Description**: Retrieves a list of reviews.

#### Response Schema

```json
{
  "reviews": [
    {
      "name": "string",
      "title": "string",
      "review": "string",
      "rating": "integer",
      "image": "string"
    }
  ]
}
### Contacts

- **Endpoint**: `/contacts`
- **Method**: `GET`
- **Description**: Retrieves a list of conatct messages.

#### Response Schema

```json
{
  "contacts": [
    {
      "id": "string",
      "fullName": "string",
      "email": "string",
      "subject": "string",
      "message": "string"
    }
  ]
}
### skillsData

- **Endpoint**: `/skillsData`
- **Method**: `GET`
- **Description**: Retrieves a list of Skills Data.

#### Response Schema

```json
{
  "skillsData": [
    {
      "id": "string",
      "domain": "string",
      "skills": [
        {
          "name": "string",
          "proficiency": "string"
        }
      ]
    }
  ]
}

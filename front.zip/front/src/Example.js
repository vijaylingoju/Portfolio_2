import NavBar from "./navBar";
import { Link } from "react-router-dom";

const navigation = [
  { name: "Home", href: "#", current: true },
  { name: "Skills", href: "#skills", current: false },
  { name: "Education", href: "#", current: false },
  { name: "Projects", href: "#projects", current: false },
  { name: "Recommendations", href: "#recommendations", current: false },
  { name: "Contact", href: "#footer", current: false },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function Example() {
  return (
    <div className="bg-white min-h-screen max-w-full overflow-x-hidden  ">
      <div className="w-full flex flex-col lg:flex-row items-center justify-center lg:justify-between p-5 lg:p-10">
        <div className="w-full lg:w-1/2 p-5 lg:p-10 text-left">
          <h1 className="text-2xl lg:text-4xl text-black font-bold mb-4">
            I'm Hyndhavi Sidda
          </h1>
          <h2 className="text-2xl lg:text-4xl text-black font-bold mb-6">
            <span className="text-yellow-500">Front-End</span> Developer
          </h2>
          <p className="text-sm lg:text-lg text-gray-400 mb-6">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis
            doloribus cum alias expedita aut ipsa sequi ducimus quos aliquam
            sunt?
          </p>
          <button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold rounded-lg text-sm lg:text-lg px-4 lg:px-6 py-2 lg:py-3 transition">
            HIRE ME <span>→</span>
          </button>
        </div>
        <div className="w-full lg:w-1/2 lg:ml-10 mt-10 lg:mt-0">
          <img
            src="https://i.ibb.co/NCT92ky/main.png"
            alt="Random"
            className="w-full rounded-lg object-cover"
          />
        </div>
      </div>
    </div>
  );
}

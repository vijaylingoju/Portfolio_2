import React from 'react'
import Projects from './projects'
import Example from './Example'
import Recommendations from './recommendations'
import ReviewList from './ReviewList'
import ContactForm from './ContactForm'
const Page1 = () => {
  return (
    <div>
      <Example/>    
      <Projects/>
      <Recommendations/>
      <ReviewList/>
      <ContactForm/>
    </div>
  )
}

export default Page1

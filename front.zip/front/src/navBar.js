import React from 'react';
import { Disclosure, DisclosureButton, DisclosurePanel } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const navigation = [
  { name: 'Home', href: '#', key: 'home' },
  { name: 'Skills', href: '#skills', key: 'skills' },
  { name: 'Education', href: '#education', key: 'education' },
  { name: 'Projects', href: '#projects', key: 'projects' },
  { name: 'Recommendations', href: '#recommendations', key: 'recommendations' },
  { name: 'Contact', href: '#contact', key: 'contact' },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

const NavBar = ({ setCurrentPage }) => {
  return (
    <div className="sticky top-0 z-50 bg-white shadow">
      <Disclosure as="nav" className="h-[100px]">
        <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8 h-full">
          <div className="relative flex items-center justify-between h-full">
            <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
              {/* Mobile menu button */}
              <DisclosureButton className="inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                <span className="sr-only">Open main menu</span>
                <Bars3Icon aria-hidden="true" className="block h-6 w-6" />
                <XMarkIcon aria-hidden="true" className="hidden h-6 w-6" />
              </DisclosureButton>
            </div>
            <div className="flex flex-1 items-center justify-center sm:items-center sm:justify-start h-full">
              <div className="flex flex-shrink-0 items-center">
                <img
                  alt="Your Company"
                  src="./logo.png"
                  className="h-[50px] w-auto"
                />
              </div>
            </div>
            <div className="hidden sm:flex sm:items-center sm:space-x-4 h-full">
              {navigation.map((item) => (
                <a
                  key={item.key}
                  href={item.href}
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(item.key);
                  }}
                  className={classNames(
                    'text-gray-500',
                    'hover:bg-yellow-400 hover:text-black',
                    'rounded-md px-3 py-2 text-sm font-medium flex items-center'
                  )}
                >
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        </div>

        <DisclosurePanel className="sm:hidden">
          <div className="space-y-1 px-2 pb-3 pt-2">
            {navigation.map((item) => (
              <DisclosureButton
                key={item.key}
                as="a"
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  setCurrentPage(item.key);
                }}
                className={classNames(
                  'text-gray-300 hover:bg-gray-700 hover:text-white',
                  'block rounded-md px-3 py-2 text-base font-medium'
                )}
              >
                {item.name}
              </DisclosureButton>
            ))}
          </div>
        </DisclosurePanel>
      </Disclosure>
    </div>
  );
};

export default NavBar;

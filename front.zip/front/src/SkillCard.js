import React from 'react';

function SkillCard({ title, skills }) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 m-4 max-w-sm w-full">
      <div className='flex justify-between mb-5 font-bold'>
        <div><h2 className="text-2xl font-semibold mb-6 text-gray-800">{title}</h2></div>
        <div><h3></h3></div>
      </div>
      <ul className="space-y-4">
        {skills.map((skill) => (
          <li key={skill.name} className="flex flex-col rounded-lg shadow-sm">
            <div className="flex justify-between items-center">
              <span className="text-lg font-medium text-gray-700">{skill.name}</span>
              <span className="text-gray-500 text-sm">{skill.proficiency}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-yellow-500 rounded-full h-3"
                style={{ width: skill.proficiency }}
              ></div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SkillCard;

import React, { useState, useRef, useEffect } from "react";
import ReviewCard from "./ReviewCard";

const ReviewList = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollContainerRef = useRef(null);
  const [reviewsData, setReviewsData] = useState([]);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await fetch("http://localhost:5000/reviews");
        const data = await response.json(); 
        setReviewsData(data);
      } catch (error) {
        console.error("Error fetching reviews:", error);
      }
    };

    fetchReviews();
  }, []);

  // Automatic horizontal scrolling
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container || !container.children.length) return;

    const cardWidth = container.children[0].getBoundingClientRect().width;
    const interval = setInterval(() => {
      container.scrollLeft += cardWidth / 2; // Adjust scroll speed here
      if (container.scrollLeft + container.clientWidth >= container.scrollWidth) {
        container.scrollLeft = 0;
      }
    }, 2000); // Adjust scroll interval time here

    return () => clearInterval(interval);
  }, [reviewsData]);

  // Handle mouse drag
  const handleMouseDown = (e) => {
    setIsDragging(true);
    setStartX(e.pageX - scrollContainerRef.current.offsetLeft);
    setScrollLeft(scrollContainerRef.current.scrollLeft);
  };

  const handleMouseLeave = () => setIsDragging(false);

  const handleMouseUp = () => setIsDragging(false);

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    const x = e.pageX - scrollContainerRef.current.offsetLeft;
    const walk = (x - startX) * 2; // Scroll speed
    scrollContainerRef.current.scrollLeft = scrollLeft - walk;
  };

  // Sync the dots with the current visible card
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container || !container.children.length) return;

    const cardWidth = container.children[0].getBoundingClientRect().width;
    const newIndex = Math.round(container.scrollLeft / cardWidth);
    setCurrentIndex(newIndex);
  }, [scrollContainerRef.current?.scrollLeft]);

  // Handle dot click to center the card
  const handleDotClick = (index) => {
    const container = scrollContainerRef.current;
    if (!container || !container.children.length) return;

    const cardWidth = container.children[0].getBoundingClientRect().width;
    container.scrollLeft = cardWidth * index;
    setCurrentIndex(index);
  };

  return (
    <div className="relative mx-auto px-4">
      <div
        ref={scrollContainerRef}
        className="flex gap-4 overflow-x-auto whitespace-nowrap scroll-smooth"
        style={{ scrollbarWidth: 'none' }}
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
      >
        {reviewsData.map((review, index) => (
          <div key={index} className="inline-block w-[350px]">
            <ReviewCard
              name={review.name} // Changed from review.author to review.name
              title={review.title}
              review={review.review} // Changed from review.content to review.review
              rating={review.rating}
              image={review.image} // Ensure charAt is only called if name is defined
            />
          </div>
        ))}
      </div>
      <div className="flex justify-center mt-4">
        {reviewsData.map((_, index) => (
          <div
            key={index}
            className={`h-2 w-2 rounded-full mx-1 cursor-pointer ${index === currentIndex ? 'bg-yellow-500' : 'bg-gray-300'}`}
            onClick={() => handleDotClick(index)}
          />
        ))}
      </div>
      <style jsx>{`
        .scroll-smooth::-webkit-scrollbar {
          display: none;
        }
        .cursor-grab {
          cursor: grab;
        }
        .cursor-grabbing {
          cursor: grabbing;
        }
      `}</style>
    </div>
  );
};

export default ReviewList;

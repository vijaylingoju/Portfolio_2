import React from 'react'

const Recommendations = () => {
  return (
    <div>
      <div>
      <div id="recommendations" className='bg-customBackground'>
        <div className="heading w-full h-[200px] flex justify-center mt-[100px]">
          <div className="headingText w-[45%] h-[200px] ">
            <h1 className="lg:text-[45px] font-semibold">Recommendations</h1>
            <p className="text-gray-500">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Est illo
              molestiae at quisquam vero voluptatibus enim incidunt. Sint, animi
              veniam.
            </p>
          </div>
        </div>
      </div>
      <div className="cards">
        
      </div>
    </div>
    </div>
  )
}

export default Recommendations

import React from "react";
import CardList from "./cardList";
const Projects = () => {
  return (
    <div>
      <div id="projects" className="bg-customBackground">
        <div className="heading w-full h-[200px] flex justify-center mt-[100px]">
          <div className="headingText w-[45%] h-[200px] ">
            <h1 className="lg:text-[45px] font-semibold">Projects</h1>
            <p className="text-gray-500">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Est illo
              molestiae at quisquam vero voluptatibus enim incidunt. Sint, animi
              veniam.
            </p>
          </div>
        </div>
      </div>
      
      <CardList/>
    </div>
  );
};

export default Projects;

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/*.js"],
  theme: {
    extend: {
      colors: {
        customBackground: '#f1f0f6', // Define a custom color
      },
    },
  },
  plugins: [],
}
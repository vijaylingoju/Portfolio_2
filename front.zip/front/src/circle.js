import React, { useState, useEffect } from 'react';

const Circle = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    const handleMouseMove = (event) => {
      setPosition({ x: event.clientX, y: event.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div
      className="fixed bg-yellow-500 w-12 h-12 rounded-full pointer-events-none"
      style={{
        top: `${position.y - 24}px`,
        left: `${position.x - 24}px`,
    
      }}
    ></div>
  );
};

export default Circle;

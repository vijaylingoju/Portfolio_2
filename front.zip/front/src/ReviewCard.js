import React from "react";

const ReviewCard = ({ name, title, review, rating, image }) => {
  return (
    <div className="bg-white rounded-md shadow-md p-6 max-w-sm mx-auto overflow-hidden">
      <div className="flex items-center mb-4">
        <div className="flex">
          {[...Array(rating)].map((_, index) => (
            <svg
              key={index}
              width="21"
              height="19"
              viewBox="0 0 21 19"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M10.2143 13.9217L14.595 12.8976L16.4253 18.1014L10.2143 13.9217ZM20.2959 7.19556H12.5847L10.2143 0.49707L7.84398 7.19556H0.132812L6.37376 11.3475L4.0034 18.046L10.2443 13.8941L14.0849 11.3475L20.2959 7.19556Z"
                fill="#FFB400"
              />
            </svg>
          ))}
        </div>
      </div>
      <h2 className="text-xl font-bold mb-4 text-left">{title}</h2>
      <p className="text-gray-700 text-base mb-5 text-left leading-relaxed">{review}</p>
      <div className="flex items-center text-left">
        <div className="w-20 h-20 rounded-full overflow-hidden mr-4">
          <img src={image} alt={name} className="w-full h-full object-cover" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-left">{name}</h3>
          <p className="text-gray-600 text-left">{title}</p>
        </div>
      </div>
    </div>
  );
};

export default ReviewCard;
